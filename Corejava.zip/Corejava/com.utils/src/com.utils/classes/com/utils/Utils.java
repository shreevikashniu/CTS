/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HARRISH
 */
package com.utils;

public class Utils {
    public static String getGreeting(String name) {
        return "Hello, " + name + "!";
    }
}
