public class ExampleClass 
{
    public void sayHello(String name) 
    {
        System.out.println("Hello, " + name);
    }
    private int square(int x) 
    {
        return x * x;
    }
}
